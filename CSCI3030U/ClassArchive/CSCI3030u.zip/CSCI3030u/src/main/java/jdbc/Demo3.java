package jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Demo3 {
	static Connection connection;

	public static void main(String[] args) {
		
		try {
			method1();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("End of the main method");
	}

	private static void method1() throws SQLException {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "XXXXX", "XXXXX");

		DatabaseMetaData dbmd;

		dbmd = connection.getMetaData();
		System.out.println(dbmd.getURL());
	}
}
