package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Demo4 {
	static Connection connection;

	public static void main(String[] args) {
		try {
			// demoDDL();
			// demoDML();
			demoDQL();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void demoDQL() throws SQLException {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "XXXXX", "XXXXX");

		Statement statement = connection.createStatement();
		String name = "Sarah";
		String query = "SELECT * FROM jdbc_student WHERE stdname = '" + name + "'";
		ResultSet rs = statement.executeQuery(query);

		while (rs.next()) {
			// System.out.print(rs.getInt("stdid") + ", ");
			// System.out.println(rs.getString("stdname"));

			System.out.print(rs.getInt(1) + ", ");
			System.out.println(rs.getString(2));
		}
	}

	public static void demoDML() throws SQLException {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "XXXXX", "XXXXX");

		Statement statement = connection.createStatement();
		statement.executeUpdate("INSERT INTO jdbc_student VALUES(4, 'Michael', 'male')");
		statement.executeUpdate("INSERT INTO jdbc_student VALUES(3, 'Sarah', 'female')");

	}

	public static void demoDDL() throws SQLException {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "XXXXX", "XXXXX");

		Statement statement = connection.createStatement();
		String query = "CREATE TABLE jdbc_student(stdid NUMBER(6) PRIMARY KEY, "
				+ "stdname VARCHAR2(20), gender VARCHAR2(10))";
		statement.execute(query);
	}
}
