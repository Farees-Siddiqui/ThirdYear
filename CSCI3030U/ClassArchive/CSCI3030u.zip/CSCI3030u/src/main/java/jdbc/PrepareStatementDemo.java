package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PrepareStatementDemo {
	static Connection connection;

	public static void main(String[] args) {
		try {
			// injection(); //HACK
			prepareStatementMethod(); // CLEAN CODE
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void prepareStatementMethod() throws SQLException {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "XXXXX", "XXXXX");

		PreparedStatement ps = connection.prepareStatement("SELECT * FROM jdbc_student WHERE stdname = ?");
//		String name = "Sarah";
		String name = "Sarah' OR 'x'='x"; 
		ps.setString(1, name);

		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			System.out.println(rs.getInt(1) + ", " + rs.getString(2) + ", " + rs.getString(3));
		}
	}

	public static void injection() throws SQLException {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "XXXXX", "XXXXX");

		Statement statement = connection.createStatement();
		String name = "Sarah' OR 'x'='x"; // HACK
		// Injection happened and all the information will be retrieved!
		ResultSet rs = statement.executeQuery("SELECT * FROM jdbc_student WHERE stdname = '" + name + "'");

		while (rs.next()) {
			System.out.println(rs.getInt(1) + ", " + rs.getString(2) + ", " + rs.getString(3));
		}
	}
}
