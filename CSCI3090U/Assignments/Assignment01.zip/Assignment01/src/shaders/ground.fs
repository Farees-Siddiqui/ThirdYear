#version 330 core

void main() {

	gl_FragColor = vec4(0.2, 0.6, 0.1, 0.5);

}