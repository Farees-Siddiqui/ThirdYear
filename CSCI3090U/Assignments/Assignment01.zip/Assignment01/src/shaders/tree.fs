#version 330 core

void main() {

	gl_FragColor = vec4(0.11, 0.22, 0.14, 1.0);

}